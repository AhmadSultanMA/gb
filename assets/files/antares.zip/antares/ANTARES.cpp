#include "ANTARES.h"
#include <WiFiClient.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>

void Antares::CreateProject(String ProjectName, String Type, String Location, String Category, String AccessKey){
	HTTPClient http;
	Serial.print("[HTTP] begin...\n");
	http.begin("http://console.antares.id:8080/api/project"); //HTTP
	http.addHeader("Content-Type", "application/json");
	http.addHeader("IoTTelkomAuth", AccessKey);
	String body="{\n";
		body +="\"name\":\""+ProjectName+"\",";
		body +="\"type\":\""+Type+"\",";
			body +="\"location\":\""+Location+"\",";
		body +="\"category\":\""+Category+"\"";
		body += "}";
	Serial.print("[HTTP] POST...\n");
	int httpCode = http.POST(body);
	if(httpCode > 0) {
			Serial.printf("[HTTP] POST... code: %d\n", httpCode);
			if(httpCode == HTTP_CODE_OK) {
					String payload = http.getString();
					Serial.println(payload);
			}
	} else {
			Serial.printf("[HTTP] POST... failed, error: %s\n", http.errorToString(httpCode).c_str());
	}
	http.end();
  }

void Antares::CreateSensor(String ProjectName, String SensorName, String AccessKey){
	HTTPClient http;
	Serial.print("[HTTP] begin...\n");
	http.begin("http://console.antares.id:8080/api/sensor/"+ProjectName); //HTTP
	http.addHeader("Content-Type", "application/json");
	http.addHeader("IoTTelkomAuth", AccessKey);
	String body="{\n";
		body +="\"name\":\""+SensorName+"\"}\n";
	Serial.print("[HTTP] POST...\n");
	Serial.print(body);
	int httpCode = http.POST(body);
	if(httpCode > 0) {
			Serial.printf("[HTTP] POST... code: %d\n", httpCode);
			if(httpCode == HTTP_CODE_OK) {
					String payload = http.getString();
					Serial.println(payload);
			}
	} else {
			Serial.printf("[HTTP] POST... failed, error: %s\n", http.errorToString(httpCode).c_str());
	}
	http.end();
}

void Antares::GetAllProject(String AccessKey){
	HTTPClient http;
	Serial.print("[HTTP] begin...\n");
	http.begin("http://console.antares.id:8080/api/project"); //HTTP
	http.addHeader("Content-Type", "application/json");
	http.addHeader("IoTTelkomAuth", AccessKey);
	Serial.print("[HTTP] GET...\n");
	int httpCode = http.GET();
	if(httpCode > 0) {
			Serial.printf("[HTTP] GET... code: %d\n", httpCode);
			if(httpCode == HTTP_CODE_OK) {
					String payload = http.getString();
					Serial.println(payload);
			}
	} else {
			Serial.printf("[HTTP] GET... failed, error: %s\n", http.errorToString(httpCode).c_str());
	}
	http.end();
}  
  
void Antares::GetAProject(String ProjectName, String AccessKey){
	HTTPClient http;
	Serial.print("[HTTP] begin...\n");
	http.begin("http://console.antares.id:8080/api/project/"+ProjectName); //HTTP
	http.addHeader("Content-Type", "application/json");
	http.addHeader("IoTTelkomAuth", AccessKey);
	Serial.print("[HTTP] GET...\n");
	int httpCode = http.GET();
	if(httpCode > 0) {
			Serial.printf("[HTTP] GET... code: %d\n", httpCode);
			if(httpCode == HTTP_CODE_OK) {
					String payload = http.getString();
					Serial.println(payload);
			}
	} else {
			Serial.printf("[HTTP] GET... failed, error: %s\n", http.errorToString(httpCode).c_str());
	}
	http.end();
}
void Antares::GetASensor(String ProjectName, String SensorName, String AccessKey){
	HTTPClient http;
	Serial.print("[HTTP] begin...\n");
	http.begin("http://console.antares.id:8080/api/sensor/"+ProjectName+"/"+SensorName); //HTTP
	http.addHeader("Content-Type", "application/json");
	http.addHeader("IoTTelkomAuth", AccessKey);
	Serial.print("[HTTP] GET...\n");
	int httpCode = http.GET();
	if(httpCode > 0) {
			Serial.printf("[HTTP] GET... code: %d\n", httpCode);
			if(httpCode == HTTP_CODE_OK) {
					String payload = http.getString();
					Serial.println(payload);
			}
	} else {
			Serial.printf("[HTTP] GET... failed, error: %s\n", http.errorToString(httpCode).c_str());
	}
	http.end();


}
void Antares::GetAllSensor(String ProjectName, String AccessKey){
	HTTPClient http;
	Serial.print("[HTTP] begin...\n");
	http.begin("http://console.antares.id:8080/api/sensor/"+ProjectName); //HTTP
	http.addHeader("Content-Type", "application/json");
	http.addHeader("IoTTelkomAuth", AccessKey);
	Serial.print("[HTTP] GET...\n");
	int httpCode = http.GET();
	if(httpCode > 0) {
			Serial.printf("[HTTP] GET... code: %d\n", httpCode);
			if(httpCode == HTTP_CODE_OK) {
					String payload = http.getString();
					Serial.println(payload);
			}
	} else {
			Serial.printf("[HTTP] GET... failed, error: %s\n", http.errorToString(httpCode).c_str());
	}
	http.end();


}

void Antares::SendData(String ProjectName, String SensorName, String AccessKey, String Value, String Unit){
	HTTPClient http;
	Serial.print("[HTTP] begin...\n");
	http.begin("http://console.antares.id:8080/api/data/"+ProjectName+"/"+SensorName); //HTTP
	http.addHeader("Content-Type", "application/json");
	http.addHeader("IoTTelkomAuth", AccessKey);
	String body="{\n";
	body +="\"value\":\""+Value+"\",";
	body +="\"unit\":\""+Unit+"\"";
	body += "}";
	Serial.print("[HTTP] POST...\n");
	int httpCode = http.POST(body);
	if(httpCode > 0) {
		Serial.printf("[HTTP] POST... code: %d\n", httpCode);
		if(httpCode == HTTP_CODE_OK) {
			String payload = http.getString();
			Serial.println(payload);
		}
	} else {
		Serial.printf("[HTTP] POST... failed, error: %s\n", http.errorToString(httpCode).c_str());
	}
	http.end();
}