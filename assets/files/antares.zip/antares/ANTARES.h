#ifndef ANTARES_H
#define ANTARES_H
#include <Arduino.h>
#include <WiFiClient.h>

class Antares
{
    public:
    void CreateProject(String ProjectName, String Type, String Location, String Category, String AccessKey);
    void CreateSensor(String ProjectName, String SensorName, String AccessKey);
    void GetAllProject(String AccessKey);
    void GetAProject(String ProjectName, String AccessKey);
    void GetAllSensor(String ProjectName, String AccessKey);
    void GetASensor(String ProjectName, String SensorName, String AccessKey);
    void SendData(String ProjectName, String SensorName, String AccessKey, String Value, String Unit);
};

#endif