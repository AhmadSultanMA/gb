#include "AntaresEthernetShield.h"
#include <Ethernet.h>
#include <SPI.h>

AntaresEthernetShield::AntaresEthernetShield(String accessKey){
    _accessKey = accessKey;
}

void AntaresEthernetShield::StartConnection(){
EthernetClient client;    
//Start Ethernet Connection    
   byte _mac[] = {0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED};
    
    if (Ethernet.begin(_mac) == 0){
        Serial.println("Failed to configure Ethernet using DHCP");
    //Check for Ethernet Hardware Present 
        if (Ethernet.hardwareStatus() == EthernetNoHardware){
        Serial.println("Ethernet Shield was not found. Sorry, can't run without hardware:(");
    
            while (true){
                delay(1);
            }
        }

        if (Ethernet.linkStatus()== LinkOFF){
            Serial.println("Ethernet cable is not connected");
        }
        
        Ethernet.begin(_mac);
        Serial.print("My IP Address : ");
        Serial.println(Ethernet.localIP());
    } else {
    Serial.print("DHCP assigned IP : ");
    Serial.println(Ethernet.localIP());
}
delay (1000); 
}

void AntaresArduinoUno::sendData(String text, String projectName, String deviceName){
  EthernetClient client;

  if (client.available()) {
    char c = client.read();
    Serial.write(c);
    delay(50);
  }
    
  String url = "/~/antares-cse/antares-id/" + projectName + "/" + deviceName;  
  Serial.println("[ANTARES] Requesting URL: " + url);
  delay(500);
  Serial.println("[ANTARES] Connecting to " + String (_serverNoHttp));

// if there's a successful connection:
  if (client.connect(_serverNoHttp, 8080)) {
    Serial.println("[ANTARES] Connected to antares.id");

    // Create JSON with Antares format
    //text.replace("\"", "\\\"");
    String body;
    body += "{";
    body += "\"m2m:cin\":{";
    body += "\"con\":\"" + text + "\"";
    body += "}";
    body += "}";
    const uint16_t bodyLength = body.length();
    Serial.println(body + "\n");
     
 // send the HTTP POST request:
    client.print(("POST ") + url + " HTTP/1.1\r\n" +
               "Host: " + _serverNoHttp + "\r\n" +
               "X-M2M-Origin: " + _accessKey + "\r\n" +
               "Accept: application/json\r\n" +
               "Connection: close\r\n" +
               "Content-Type: application/json;ty=4\r\n"
                "Content-Length: " + String(bodyLength) + "\r\n\r\n" +
               body);
   
    client.println();
     

 // note the time that the connection was made:
  } else {
 // if you couldn't make a connection:
    Serial.println("[ANTARES] Connection Failed");
  }
  delay(50);
  client.stop();
}


