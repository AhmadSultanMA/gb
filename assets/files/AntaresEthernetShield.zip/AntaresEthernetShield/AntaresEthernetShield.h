#ifndef AntaresEthernetShield_H
#define AntaresEthernetShield_H
#include <Arduino.h>



class AntaresArduinoUno {
    public:
        AntaresEthernetShield(String accessKey);
        void StartConnection();
        void sendData(String text, String projectName, String deviceName);
        
    private:
        String _accessKey;
        const char* _serverNoHttp = "platform.antares.id";
        
};
#endif        


